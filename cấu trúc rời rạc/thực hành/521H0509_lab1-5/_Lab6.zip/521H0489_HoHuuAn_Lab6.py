import math
#====================Ex1====================
print("Ex1")
def isPrime(n):
    if n <= 1:
        return False
    for i in range(2, math.floor(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True
def nextPrime(n):
    if n < 2:
        return 2

    if n % 2 == 0:
        n += 1
    else:
        n += 2

    while not (isPrime(n)):
        n += 2
    return n

print(nextPrime(1))
print(nextPrime(3))
print(nextPrime(11))
print(nextPrime(19))
for i in range(100):
    print(i) if isPrime(i) else print(end='')

#====================Ex2====================
print("Ex2")
def primeFact(p):
    result = []
    prime = 2
    while p != 1:
        if p % prime == 0:
            result.append(prime)
            p /= prime
        else:
            prime = nextPrime(prime)
    return result

def countSameNumber(list):
    dict = {}
    for i in list:
        oldValue = dict.get(i)
        oldValue = oldValue if oldValue != None else 0
        dict.update({i: int(oldValue) + 1})

    return dict


print(primeFact(60))
print(countSameNumber(primeFact(60)))

#====================Ex3====================
print("Ex3")
def printPrime(N):
    for i in range(N):
        print(i) if isPrime(i) else print(end='')
printPrime(100)

#====================Ex4====================
print("Ex4")
def ex4(n):
    if n < 2:
        return []
    O = [2]
    
    i = 3
    while True:
        Flag = True
        j = 0
        if i % O[j] == 0:
            Flag = False
            if i+2 < n:
                i += 2
            else:
                return O
            
        if j + 1 < len(O):
            j += 1
            if i % O[j] == 0:
                Flag = False
            if i+2 < n:
                i += 2
            else:
                return O
        
        if Flag == True:
            O.append(i)

print(ex4(10))         
print(ex4(20))         
print(ex4(5))

#====================Ex5====================
print("Ex5")
def gcd(a,b):
    r=a%b
    while r:
        a=b
        b=r
        r=a%b
    return b
print(gcd(5,10))

#====================Ex6====================
print("Ex6")
def lcm(x, y):
   if x > y:
       greater = x
   else:
       greater = y

   while(True):
       if((greater % x == 0) and (greater % y == 0)):
           lcm = greater
           break
       greater += 1
   return lcm

print(gcd(5,7))
print(lcm(5,10) * gcd(5,10))
#====================Ex7====================
print("Ex7")
# def decimalToBinary(x):
#     binary = [0] * x
#     i = 0
#     while (x > 0):
#         binary[i] = x % 2
#         x = int(x / 2)
#         i += 1
#     for j in range(i - 1, -1, -1):
#         print(binary[j], end = "")
def decimalToBinary(number):
    integerPart = 0
    fractionalPart = 0.
    if isinstance(number, float):
        number = str(number)
        fractionalPart = float( number[ number.index(".") : ] )
        integerPart = int( number[ : number.index(".") ] )
    else:
        integerPart = number
    output = ""
    
    while integerPart != 0:
        output = str( integerPart % 2 ) + output
        integerPart //= 2
    
    if fractionalPart == 0:
        return output
    
    output += "."
    
    precision = 15
    while fractionalPart != 0 and precision != 0 :
        fractionalPart *= 2
        fractionalPartString = str(fractionalPart)
        output += fractionalPartString[ : fractionalPartString.index(".") ]
        fractionalPart = float( fractionalPartString[ fractionalPartString.index(".") : ] )
        precision -= 1
    return output

print(decimalToBinary(5))
print(decimalToBinary(15))

#====================Ex8====================
print("Ex8")

print(decimalToBinary(5.5))
print(decimalToBinary(5.25))
#====================Ex9====================
print("Ex9")
hex_dict = {0: '0',
            1: '1',
            2: '2',
            3: '3',
            4: '4',
            5: '5',
            6: '6',
            7: '7',
            8: '8',
            9: '9',
            10: 'A',
            11: 'B',
            12: 'C',
            13: 'D',
            14: 'E',
            15: 'F'}

def decimal_to_hex(num, hex):
    if num == 0:
        return hex
    remainder = num % 16
    return decimal_to_hex(num // 16, hex_dict[remainder] + hex)

print(decimal_to_hex(1023,""))
#====================Ex10====================
print("Ex10")
def convertbase(a,base1,base2):
    if base1 == 10 and base2 == 16:
        return hex(a).replace("0x", "")
    if base1 == 10 and base2 == 2:
        return bin(a).replace("0b", "")
    
    if base1 == 2 and base2 == 10:
        return int(a, 2) 
    if base1 == 2 and base2 == 16:
        return hex(int(a, 2) ).replace("0x", "")
    
    if base1 == 16 and base2 == 2:  
        return bin(int(a, base=16)).replace("0b", "")
    if base1 == 16 and base2 == 10:
        return int(a, base=16)
    

print(convertbase('3ff', 16, 2))
